// Include the Compromise library in index.html:
// <script src="https://unpkg.com/compromise"></script>

const faqResponses = {
    greeting: {
        synonyms: ["hi", "hello", "hey", "greetings", "howdy"],
        response: "Hello! I am Jal Raksha Assistant, here to help with water conservation. How can I assist you today?"
    },
    waterFootprint: {
        synonyms: ["water footprint", "water usage", "calculate water", "footprint calculation"],
        response: "To calculate your water footprint, provide your Direct Water Use and Indirect Water Use (in liters). The formula is: Water Footprint = Direct Use + Indirect Use."
    },
    conservationSteps: {
        synonyms: ["water conservation", "save water", "reduce water usage", "conserve water"],
        response: "Here are steps to conserve water: 1. Fix leaks, 2. Use efficient appliances, 3. Reduce water waste, 4. Harvest rainwater, 5. Reuse greywater."
    },
    waterScarcityMeasures: {
        synonyms: ["prevent water scarcity", "water scarcity", "water crisis", "scarcity solutions"],
        response: "To combat water scarcity: 1. Better irrigation, 2. Desalination, 3. Water management, 4. Public awareness, 5. Recycling."
    },
    generalQuery: {
        synonyms: ["what", "how", "why", "tell me about", "explain", "inform me about"],
        response: "Feel free to ask about water conservation, steps to prevent water scarcity, or how to calculate your water footprint. I am here to assist!"
    }
};

// Function to calculate water footprint based on user inputs
function calculateWaterFootprint(direct, indirect) {
    const total = direct + indirect;
    return `Your total water footprint is ${total} liters. Direct Use: ${direct} liters, Indirect Use: ${indirect} liters.`;
}

// New function using Compromise to process input with NLP capabilities
function getNLPResponse(userInput) {
    let doc = nlp(userInput.toLowerCase());  // Process input using Compromise

    // Recognize greetings
    if (doc.has('(hi|hello|hey|greetings|howdy)')) {
        return faqResponses.greeting.response;
    }

    // Recognize queries about water footprint
    if (doc.has('(water footprint|water usage|calculate water|footprint calculation)')) {
        return faqResponses.waterFootprint.response;
    }

    // Recognize queries about conservation steps
    if (doc.has('(water conservation|save water|reduce water usage|conserve water)')) {
        return faqResponses.conservationSteps.response;
    }

    // Recognize queries about water scarcity measures
    if (doc.has('(prevent water scarcity|water scarcity|water crisis|scarcity solutions)')) {
        return faqResponses.waterScarcityMeasures.response;
    }

    // If the query doesn't match any predefined categories, handle as a general query
    if (doc.has('(what|how|why|tell me about|explain|inform me about)')) {
        return faqResponses.generalQuery.response;
    }

    // Advanced fallback for handling unknown queries
    let entities = doc.topics().out('array');
    if (entities.length > 0) {
        return `It seems you're asking about "${entities.join(', ')}". Could you clarify your question further, or ask about water conservation or water footprint?`;
    }

    // General fallback if no match is found: redirect to contact form
    return `I'm sorry, I don't have an answer for that right now. Please contact us via email at <a href="mailto:support@jalraksha.com">support@jalraksha.com</a> or fill out the contact form <a href="contact.html">here</a>.`;
}

// Event listeners for chatbot interactions
document.getElementById('chat-icon').onclick = function() {
    const chatbot = document.getElementById('chatbot');
    chatbot.style.display = chatbot.style.display === 'none' ? 'block' : 'none';
};

document.getElementById('sendButton').onclick = function() {
    const userInput = document.getElementById('userInput').value;
    const response = getNLPResponse(userInput);  // Use enhanced NLP to generate a response
    document.getElementById('messages').innerHTML += `<div><b>User:</b> ${userInput}</div><div><b>Jal Raksha:</b> ${response}</div>`;
    document.getElementById('userInput').value = ''; 
};

document.getElementById('cancelButton').onclick = function() {
    document.getElementById('chatbot').style.display = 'none'; 
    document.getElementById('messages').innerHTML = ''; 
};
